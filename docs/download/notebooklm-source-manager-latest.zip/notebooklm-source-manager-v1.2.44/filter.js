document.addEventListener("DOMContentLoaded", function() {
  /////////////////////////////////////////////////////////////
  // 0. i18n属性によるテキストの置換処理
  /////////////////////////////////////////////////////////////
  // data-i18n または data-i18n-placeholder 属性を持つ要素のテキストを更新する
  document.querySelectorAll('[data-i18n], [data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n') || el.getAttribute('data-i18n-placeholder');
    const message = chrome.i18n.getMessage(key);
    if (message) {
      // placeholder 属性がある場合はそれを更新、なければ innerText を更新
      if (el.hasAttribute("data-i18n-placeholder")) {
        el.setAttribute("placeholder", message);
      } else {
        el.innerText = message;
      }
    }
  });
  
  /////////////////////////////////////////////////////////////
  // 1. i18n (JS内で利用する場合)
  /////////////////////////////////////////////////////////////
  function i18nMessage(key) {
    return chrome.i18n.getMessage(key) || key;
  }

  // タイトルなどの設定（すでにHTML側で更新済みの場合は補完）
  const titleEl = document.getElementById("title");
  if (titleEl && !titleEl.innerText.trim()) {
    titleEl.innerText = i18nMessage("filterTitle") || "フィルターウィンドウ";
  }
  const versionLabelEl = document.getElementById("versionLabel");
  if (versionLabelEl && !versionLabelEl.innerText.trim()) {
    versionLabelEl.innerText = i18nMessage("versionLabel") || "バージョン";
  }

  // フッターのバージョン表示を manifest の version で埋める（ハードコードの 1.0.0 を置換）
  try {
    const verEl = document.getElementById('versionValue');
    if (verEl) {
      // chrome.runtime.getManifest が利用可能なら manifest.version を使う
      const manifest = (chrome && chrome.runtime && typeof chrome.runtime.getManifest === 'function') ? chrome.runtime.getManifest() : null;
      if (manifest && manifest.version) {
        verEl.innerText = manifest.version;
      }
    }
  } catch (e) {
    console.warn('could not set version from manifest', e);
  }

  // タブ切替処理
  const tabs = document.querySelectorAll(".tab");
  const tabContents = document.querySelectorAll(".tab-content");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tabContents.forEach(tc => tc.classList.remove("active"));
      tab.classList.add("active");
      let activeTab = tab.getAttribute("data-tab");
      let content = document.getElementById(activeTab);
      if (content) content.classList.add("active");
    });
  });

  /////////////////////////////////////////////////////////////
  // 2. ソース一覧表示とフィルタ処理
  /////////////////////////////////////////////////////////////
  let sources = [];
  let filteredSources = [];

  function initSourceSelection(list) {
    return list.map(s => {
      s.selected = false;
      if (!s.type) s.type = "Unknown";
      return s;
    });
  }

  // ソース種別のアイコンおよびツールチップ定義
  function getTypeMapping(type) {
    const typeMap = {
    "article":            { icon: "\ud83d\udcf0", tooltip: "Docs" },
    "description":        { icon: "\ud83d\udcc3", tooltip: "TXT" },
    "text":               { icon: "\ud83d\udcc3", tooltip: "TXT" },
    "drive_pdf":          { icon: "\ud83d\udcc4", tooltip: "PDF" },
    // some sources use 'presentation' while others use 'drive_presentation'
    "drive_presentation": { icon: "\ud83d\udcca", tooltip: "PPT" },
    "presentation":       { icon: "\ud83d\udcca", tooltip: "PPT" },
    // documents vs generic articles
    "document":           { icon: "\ud83d\udcc4", tooltip: "DOC" },
    "markdown":           { icon: "\ud83d\udcdd", tooltip: "MD" },
    // audio / voice mapping
    "audio":              { icon: "\ud83c\udfa7", tooltip: "VOICE" },
    "video_audio_call":   { icon: "\ud83d\udcde", tooltip: "VOICE" },
    "video_youtube":      { icon: "\ud83d\udcfa", tooltip: "YouTube" },
    "web":                { icon: "\ud83c\udf10", tooltip: "WEB" },
    "Unknown":            { icon: "\u2753", tooltip: "Unknown" }
    };
    return typeMap[type] || typeMap["Unknown"];
  }

  // ソース種別アイコン要素生成
  function getTypeIconElement(type) {
    let mapping = getTypeMapping(type);
    let span = document.createElement("span");
    span.innerText = mapping.icon;
    span.title = mapping.tooltip;
    span.style.marginRight = "5px";
    span.style.fontSize = "1.2em";
    return span;
  }

  // For text-type, prefer different icons based on origin (file/manual)
  function getIconForSource(s) {
    if (s.type === 'text') {
      if (s.origin === 'file') return { icon: '📄', tooltip: 'TXT (file)' };
      if (s.origin === 'manual') return { icon: '✏️', tooltip: 'TXT (manual)' };
      return { icon: '📃', tooltip: 'TXT' };
    }
    return getTypeMapping(s.type || 'Unknown');
  }

  // ソース一覧の描画
  function renderSources() {
    let list = document.getElementById("sourceList");
    if (!list) return;
    list.innerHTML = "";

    // 全選択／全解除チェックボックスと重複チェックボタン
    let selectAllLi = document.createElement("li");
    let selectAllCb = document.createElement("input");
    selectAllCb.type = "checkbox";
    selectAllCb.id = "selectAll";
    let allChecked = (filteredSources.length > 0) && filteredSources.every(x => x.selected);
    selectAllCb.checked = allChecked;
    selectAllCb.addEventListener("change", function() {
      let check = this.checked;
      filteredSources.forEach(s => {
        let found = sources.find(x => x.id === s.id);
        if (found) {
          found.selected = check;
          s.selected = check;
        }
      });
      renderSources();
    });
    selectAllLi.appendChild(selectAllCb);

    let selAllLabel = document.createElement("strong");
    selAllLabel.innerText = i18nMessage("selectAll") || "全選択／全解除";
    selectAllLi.appendChild(selAllLabel);

    // 重複チェックボタン（対象は表示されているソースのみ）
    let dupBtn = document.createElement("button");
    dupBtn.id = "checkDuplicatesButton";
    dupBtn.innerText = i18nMessage("duplicateCheckButton") || "重複チェック";
    dupBtn.style.marginLeft = "10px";
    dupBtn.addEventListener("click", checkDuplicates);
    selectAllLi.appendChild(dupBtn);

    list.appendChild(selectAllLi);

    // 各ソース行の生成（アイコン付き）
    filteredSources.forEach(s => {
      let li = document.createElement("li");
      let cbox = document.createElement("input");
      cbox.type = "checkbox";
      cbox.dataset.id = s.id;
      cbox.checked = s.selected;
      cbox.addEventListener("change", function() {
        let found = sources.find(x => x.id === s.id);
        if (found) {
          found.selected = this.checked;
          s.selected = this.checked;
        }
      });
      li.appendChild(cbox);

  let iconInfo = getIconForSource(s);
  let iconEl = document.createElement('span');
  iconEl.innerText = iconInfo.icon;
  iconEl.title = iconInfo.tooltip;
  iconEl.style.marginRight = '5px';
  iconEl.style.fontSize = '1.2em';
  li.appendChild(iconEl);

      li.appendChild(document.createTextNode(s.title));
      list.appendChild(li);
    });
  }

  // フィルタ処理（フィルタテキスト、並べ替え、ソース種別フィルタを適用）
  function updateFilteredSources() {
    let filterVal = (document.getElementById("filterInput") || {}).value || "";
    let sortVal = (document.getElementById("sortOrder") || {}).value || "default";
    let useRegex = (document.getElementById("regexFilter") || {}).checked;

    let tmp;
    if (useRegex) {
      try {
        let re = new RegExp(filterVal, "i");
        tmp = sources.filter(s => {
          let text = (s.title + " " + s.type).toLowerCase();
          return re.test(text);
        });
      } catch (e) {
        console.warn("Invalid regex:", e);
        tmp = [];
      }
    } else {
      let lower = filterVal.trim().toLowerCase();
      tmp = sources.filter(s => {
        let text = (s.title + " " + s.type).toLowerCase();
        return text.includes(lower);
      });
    }

    // ソース種別フィルタの適用（表示されているソースのみ）
    let typeCbs = document.querySelectorAll("#sourceTypeFilters input[type=checkbox]");
    let selectedTypes = [];
    typeCbs.forEach(cb => {
      if (cb.checked) selectedTypes.push(cb.value);
    });
    if (selectedTypes.length > 0) {
      tmp = tmp.filter(x => selectedTypes.includes(x.type));
    }

    // ソート処理
    if (sortVal === "asc") {
      tmp.sort((a, b) => a.title.localeCompare(b.title));
    } else if (sortVal === "desc") {
      tmp.sort((a, b) => b.title.localeCompare(a.title));
    }

    filteredSources = tmp;
    renderSources();
  }

  // ソース種別フィルタ用チェックボックス群の生成
  function renderSourceTypeFilters() {
    let container = document.getElementById("sourceTypeFilters");
    if (!container) return;
    container.innerHTML = "";
    let types = Array.from(new Set(sources.map(s => s.type))).sort();
    types.forEach(t => {
      let cb = document.createElement("input");
      cb.type = "checkbox";
      cb.value = t;
      cb.id = "type_" + t;
      cb.addEventListener("change", updateFilteredSources);

      let lab = document.createElement("label");
      lab.htmlFor = "type_" + t;
      let iconEl = getTypeIconElement(t);
      lab.appendChild(iconEl);
      lab.appendChild(document.createTextNode(getTypeMapping(t).tooltip));
      container.appendChild(cb);
      container.appendChild(lab);
    });
  }

  // エラーメッセージ表示用
  function displayError(msg) {
    let err = document.getElementById("errorMessage");
    if (err) err.innerText = msg;
  }
  function clearError() {
    let err = document.getElementById("errorMessage");
    if (err) err.innerText = "";
  }

  // ---- 使い方の枠 -------------------------------------------------------
  // 初回は開いた状態で表示し、閉じたらその状態を覚えておく。
  // 毎回同じ説明が場所を取るのは邪魔なので、慣れたユーザーには畳ませる。
  function setupHelpBoxes() {
    document.querySelectorAll('details.help-box').forEach(box => {
      const key = 'helpOpen:' + box.id;
      let stored = null;
      try { stored = localStorage.getItem(key); } catch (e) { /* 参照できなければ既定値 */ }
      if (stored !== null) box.open = (stored === '1');
      box.addEventListener('toggle', () => {
        try { localStorage.setItem(key, box.open ? '1' : '0'); } catch (e) {}
      });
    });
  }

  // ---- 状態バナー -------------------------------------------------------
  // 「一覧が空」には理由が複数ある（タブを見失った／ノートブック未表示／
  // content script 未注入／本当にソースが0件）。区別せず黙って空表示すると
  // ユーザーは故障と区別できないため、理由と次の一手を必ず出す。
  function hideBanner() {
    const el = document.getElementById("statusBanner");
    if (el) el.className = "";
  }

  function showBanner(kind, title, body, actions) {
    const el = document.getElementById("statusBanner");
    if (!el) return;
    el.className = "is-visible " + (kind === "info" ? "is-info" : "is-warn");
    document.getElementById("statusBannerTitle").innerText = title || "";
    document.getElementById("statusBannerBody").innerText = body || "";
    const box = document.getElementById("statusBannerActions");
    box.innerHTML = "";
    (actions || []).forEach(a => {
      const b = document.createElement("button");
      b.innerText = a.label;
      b.addEventListener("click", () => a.onClick(b));
      box.appendChild(b);
    });
  }

  // 対象タブを再読み込みして復旧を試みる導線
  function reloadNotebookTab(btn) {
    if (btn) { btn.disabled = true; btn.innerText = i18nMessage("bannerReloading"); }
    chrome.runtime.sendMessage({ action: "reloadNotebookTab" }, (resp) => {
      if (chrome.runtime.lastError || (resp && resp.error)) {
        showLoadFailureBanner((resp && resp.errorCode) || "SCRIPT_UNAVAILABLE");
        return;
      }
      reloadSources();
    });
  }

  function showLoadFailureBanner(errorCode) {
    const retry = { label: i18nMessage("bannerRetry"), onClick: () => reloadSources() };
    const reload = { label: i18nMessage("bannerReloadTab"), onClick: (b) => reloadNotebookTab(b) };
    const title = i18nMessage("bannerTitle_" + errorCode);
    const body = i18nMessage("bannerBody_" + errorCode);
    // 再読み込みで直るのは content script 未注入のときだけ
    const actions = errorCode === "SCRIPT_UNAVAILABLE" ? [reload, retry] : [retry];
    showBanner("warn", title, body, actions);
  }

  // ソース再読み込み
  // autoRetried: 自動再試行を既に行ったか（フェイルセーフの二重発火を防ぐ）
  function reloadSources(autoRetried) {
    chrome.runtime.sendMessage({ action: "getSources" }, (resp) => {
      if (chrome.runtime.lastError) {
        // background 自体に届かない＝Service Worker 起動待ちの可能性がある。
        // 一度だけ間を置いて自動で仕切り直す。
        if (!autoRetried) {
          setTimeout(() => reloadSources(true), 600);
          return;
        }
        showLoadFailureBanner("SCRIPT_UNAVAILABLE");
        return;
      }
      if (resp && resp.error) {
        showLoadFailureBanner(resp.errorCode || "SCRIPT_UNAVAILABLE");
        displayError("");
        return;
      }
      if (resp && Array.isArray(resp.sources)) {
        clearError();
        sources = initSourceSelection(resp.sources);
        filteredSources = [...sources];
        updateFilteredSources();
        renderSourceTypeFilters();
        if (sources.length === 0) {
          // 0件が正常なケース（空のノートブック）と、失敗を取り違えないよう明示する
          showBanner("info",
            i18nMessage("bannerTitle_EMPTY"),
            i18nMessage("bannerBody_EMPTY"),
            [{ label: i18nMessage("bannerRetry"), onClick: () => reloadSources() }]);
        } else {
          hideBanner();
        }
      } else {
        showLoadFailureBanner("SCRIPT_UNAVAILABLE");
      }
    });
  }

  // 重複チェック（表示されている filteredSources のみ対象）
  function checkDuplicates() {
    let seen = new Map();
    filteredSources.forEach(s => {
      if (seen.has(s.title)) {
        s.selected = true;
      } else {
        seen.set(s.title, true);
        s.selected = false;
      }
    });
    // 同じ内容を sources にも反映
    filteredSources.forEach(s => {
      let orig = sources.find(x => x.id === s.id);
      if (orig) {
        orig.selected = s.selected;
      }
    });
    renderSources();
  }

  /////////////////////////////////////////////////////////////
  // 3. CSVダウンロード (削除モード)
  let csvBtn = document.createElement("button");
  csvBtn.id = "downloadCsvBtn";
  csvBtn.innerText = i18nMessage("downloadCsvButton") || "Download CSV";
  csvBtn.style.marginLeft = "10px";
  csvBtn.addEventListener("click", () => downloadCsv(csvBtn));

  // 「ソース情報も含める」チェックボックス。
  // ON にすると NotebookLM が持っている URL・YouTube 動画ID・
  // Google Drive ファイルID・語数などを CSV に載せる。
  let csvDetailWrap = document.createElement("label");
  csvDetailWrap.id = "csvDetailWrap";
  csvDetailWrap.className = "csv-detail-toggle";
  let csvDetailChk = document.createElement("input");
  csvDetailChk.type = "checkbox";
  csvDetailChk.id = "csvIncludeDetails";
  let csvDetailText = document.createElement("span");
  csvDetailText.innerText = i18nMessage("csvIncludeDetails") || "Include source details";
  csvDetailWrap.appendChild(csvDetailChk);
  csvDetailWrap.appendChild(csvDetailText);
  csvDetailWrap.title = i18nMessage("csvIncludeDetailsTip") || "";

  // 選択状態を次回に持ち越す
  try {
    csvDetailChk.checked = localStorage.getItem("csvIncludeDetails") === "1";
  } catch (e) { /* localStorage 不可でも動作は続ける */ }
  csvDetailChk.addEventListener("change", () => {
    try {
      localStorage.setItem("csvIncludeDetails", csvDetailChk.checked ? "1" : "0");
    } catch (e) { /* 同上 */ }
  });

  let delSelBtn = document.getElementById("deleteSelected");
  if (delSelBtn) {
    delSelBtn.insertAdjacentElement("afterend", csvBtn);
    csvBtn.insertAdjacentElement("afterend", csvDetailWrap);
  }

  // サーバー側の種別コード → 表示ラベル
  const SERVER_TYPE_MESSAGE_KEYS = {
    1: "srcTypeGoogleDoc",
    2: "srcTypeGoogleSlides",
    3: "srcTypePdf",
    4: "srcTypeText",
    5: "srcTypeWebPage",
    8: "srcTypeMarkdown",
    9: "srcTypeYoutube"
  };
  function serverTypeLabel(code) {
    // コードなしはアップロードされた PDF
    if (code === null || code === undefined) return i18nMessage("srcTypePdfUploaded");
    const key = SERVER_TYPE_MESSAGE_KEYS[code];
    return key ? i18nMessage(key) : "code:" + code;
  }

  function csvCell(v) {
    if (v === null || v === undefined) return '""';
    return '"' + String(v).replace(/"/g, '""') + '"';
  }

  const CSV_DETAIL_HEADERS = [
    "Title", "Type", "URL", "YouTubeVideoId", "YouTubeChannel", "DriveFileId",
    "WordCount", "Bytes", "DurationSec", "AddedAt", "IngestedAt",
    "MimeType", "InternalFlag", "SourceId"
  ];

  function requestSourceDetails() {
    return new Promise(resolve => {
      chrome.runtime.sendMessage({ action: "getSourceDetails" }, resp => {
        if (chrome.runtime.lastError) {
          resolve({ error: chrome.runtime.lastError.message || "SCRIPT_UNAVAILABLE" });
          return;
        }
        resolve(resp || { error: "NO_RESPONSE" });
      });
    });
  }

  function saveCsv(lines) {
    // 先頭に BOM を付ける。付けないと Excel が UTF-8 と判定できず、
    // 日本語タイトルが文字化けする。
    const blob = new Blob(["\ufeff" + lines.join("\r\n")],
                          { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "filtered_sources.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async function downloadCsv(btn) {
    // チェックなし = 従来どおりタイトルと種別だけ
    if (!csvDetailChk.checked) {
      const lines = [["Title", "Type"].map(csvCell).join(",")];
      for (const s of filteredSources) {
        lines.push([s.title, s.type].map(csvCell).join(","));
      }
      saveCsv(lines);
      return;
    }

    if (btn) { btn.disabled = true; }
    let resp;
    try {
      resp = await requestSourceDetails();
    } finally {
      if (btn) { btn.disabled = false; }
    }

    // 取得できなければ CSV を出さずに中断する。
    // 中途半端に空欄だらけの CSV を渡すと、値が無いのか取得に失敗したのか
    // 区別できないため。
    if (!resp || resp.error || !resp.details) {
      const code = (resp && resp.error) || "UNKNOWN";
      showBanner("warn",
        i18nMessage("csvDetailErrorTitle"),
        i18nMessage("csvDetailErrorBody") + "（" + code + "）",
        [{ label: i18nMessage("bannerRetry"), onClick: () => { hideBanner(); downloadCsv(btn); } }]);
      return;
    }
    hideBanner();

    const details = resp.details;
    const lines = [CSV_DETAIL_HEADERS.map(csvCell).join(",")];
    for (const s of filteredSources) {
      const d = (s.notebookSourceId && details[s.notebookSourceId]) || null;
      // サーバー側に該当が無い場合のみ、DOM から推定した種別で埋める
      lines.push([
        s.title,
        d ? serverTypeLabel(d.typeCode) : s.type,
        d && d.url,
        d && d.youtubeVideoId,
        d && d.youtubeChannel,
        d && d.driveFileId,
        d && d.wordCount,
        d && d.bytes,
        d && d.durationSec,
        d && d.addedAt,
        d && d.ingestedAt,
        d && d.mimeType,
        d && d.internalFlag,
        s.notebookSourceId
      ].map(csvCell).join(","));
    }
    saveCsv(lines);
  }

  /////////////////////////////////////////////////////////////
  // 4. YouTube 一括追加モードは専用ハンドラが下で定義されています
  function addSourceUrl(url) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action: "addSource", url }, resp => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError.message);
        } else {
          resolve(resp);
        }
      });
    });
  }

  // 新 UI の追加ダイアログは改行区切りで複数 URL を一度に受け付けるため、
  // 1件ずつダイアログを開き直さずまとめて投入する
  function addSourceUrls(urls) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action: "addSources", urls }, resp => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError.message);
        } else {
          resolve(resp);
        }
      });
    });
  }

  // --- YouTube 専用一括追加ハンドラ ---
  function isYouTubeUrl(u) {
    try {
      let url = new URL(u);
      let host = url.hostname.replace(/^www\./, '');
      return host === 'youtube.com' || host === 'youtu.be' || host === 'm.youtube.com';
    } catch (e) {
      return false;
    }
  }

  // 短縮リンクやパラメータ付き URL を watch?v= フォーマットに正規化
  function normalizeYouTubeUrl(u) {
    try {
      let url = new URL(u);
      let host = url.hostname.replace(/^www\./, '');
      if (host === 'youtu.be') {
        // youtu.be/<id>
        let id = url.pathname.replace(/^\//, '');
        if (!id) return null;
        return `https://www.youtube.com/watch?v=${id}`;
      }
      // host is youtube.com or m.youtube.com etc.
      if (url.pathname === '/watch') {
        let v = url.searchParams.get('v');
        return v ? `https://www.youtube.com/watch?v=${v}` : null;
      }
      // share/embed paths like /embed/<id>
      let m = url.pathname.match(/\/embed\/(.+)$/);
      if (m && m[1]) return `https://www.youtube.com/watch?v=${m[1]}`;
      // sometimes the id is directly in pathname
      m = url.pathname.match(/\/v\/(.+)$/);
      if (m && m[1]) return `https://www.youtube.com/watch?v=${m[1]}`;
      return null;
    } catch (e) {
      return null;
    }
  }

  const addYtBtn = document.getElementById('addYtButton');
  if (addYtBtn) {
    addYtBtn.addEventListener('click', async () => {
      const textarea = document.getElementById('ytTextarea');
      const errorDiv = document.getElementById('ytError');
      const prog = document.getElementById('ytProgress');
      const stat = document.getElementById('ytProgressStatus');
      if (!textarea || !errorDiv || !prog || !stat) return;

      let lines = textarea.value.split(/\r?\n/).map(x => x.trim()).filter(x => x);
      if (!lines.length) return;

      // validate/normalize
      let normalized = [];
      let bad = [];
      for (let l of lines) {
        // try direct URL parse, if missing scheme add https://
        let candidate = l;
        if (!/^https?:\/\//i.test(candidate)) candidate = 'https://' + candidate;
        if (!isYouTubeUrl(candidate)) {
          bad.push(l);
          continue;
        }
        let n = normalizeYouTubeUrl(candidate);
        if (!n) {
          bad.push(l);
        } else {
          normalized.push(n);
        }
      }

      if (normalized.length === 0) {
        errorDiv.innerText = 'No valid YouTube URLs found.\n' + (bad.slice(0,5).join('\n') || '');
        return;
      }

      prog.max = normalized.length;
      prog.value = 0;
      let errors = [];
      stat.innerText = `Start: ${normalized.length}`;

      // 新 UI は一度のダイアログ操作でまとめて投入できるため、進捗は
      // 「送信 → 完了」の2段階になる（1件ずつ開き直すより大幅に速い）
      try {
        let resp = await addSourceUrls(normalized);
        if (resp && resp.error) throw resp.error;
        prog.value = normalized.length;
      } catch (e) {
        errors.push(`${normalized.length} URL(s) => ${e}`);
      }

      if (errors.length) {
        errorDiv.innerText = errors.join('\n');
        // 失敗時は再試行できるよう入力を残す
      } else {
        errorDiv.innerText = '';
        textarea.value = '';
      }
      stat.innerText = `Progress: ${errors.length ? 0 : normalized.length}/${normalized.length}, ERR: ${errors.length}`;
      stat.innerText += '\nDone.';
      // refresh source list
      reloadSources();
    });
  }

  /////////////////////////////////////////////////////////////
  // 5. リネームモード
  function parseCSVLine(line) {
    let re = /(?:\s*"([^"]*)"\s*|\s*([^",]+)\s*)(?:,|$)/g;
    let result = [];
    let m;
    while ((m = re.exec(line)) !== null) {
      result.push(m[1] !== undefined ? m[1] : m[2]);
    }
    return result.length === 2 ? result : null;
  }
  let renameBtn = document.getElementById("renameButton");
  if (renameBtn) {
    renameBtn.addEventListener("click", () => {
      let textarea = document.getElementById("renameTextarea");
      let errorDiv = document.getElementById("renameError");
      let renameProg = document.getElementById("renameProgress");
      let renameStat = document.getElementById("renameStatus");
      if (!textarea || !errorDiv || !renameProg || !renameStat) return;

      let lines = textarea.value.split(/\r?\n/).map(x => x.trim()).filter(x => x);
      let pairs = lines.map(parseCSVLine).filter(x => x !== null).map(([o, n]) => ({ title: o, newTitle: n }));
      if (!pairs.length) {
        errorDiv.innerText = i18nMessage("renameEmptyCsv");
        return;
      }

      errorDiv.innerText = "";
      renameProg.max = pairs.length;
      renameProg.value = 0;
      renameStat.innerText = i18nMessage("renameProgressRunning") + " (" + pairs.length + ")";

      chrome.runtime.sendMessage({ action: "renameSources", renamePairs: pairs }, resp => {
        if (resp.error) {
          errorDiv.innerText = i18nMessage("renameErrorMessage") + ": " + resp.error;
          return;
        }
        let results = resp.result || [];
        let failed = results.filter(x => x.status !== "renamed");
        if (failed.length > 0) {
          errorDiv.innerText = failed.map(f => `${f.oldTitle} => ${f.newTitle}: ${f.status}${f.error ? "(" + f.error + ")" : ""}`).join("\n");
        } else {
          errorDiv.innerText = "";
        }
        renameProg.value = pairs.length;
        renameStat.innerText = i18nMessage("renameComplete");
      });
    });
  }

  /////////////////////////////////////////////////////////////
  // 6. （旧）マスターウィンドウ制御は廃止した
  //
  // 以前は localStorage に「マスター」の印を書き、5秒以内に別のウィンドウが
  // 開かれた場合は window.close() で自分を閉じていた。しかしこの仕組みには
  // 次の問題があった。
  //   - 印の解除を unload に頼っていた。unload は廃止予定で発火しないことが多く、
  //     印が消えないまま残る（DevTools も「Unload event listeners are deprecated」と警告）
  //   - タイムスタンプは開いた時に一度書くだけで更新しないため、
  //     「5秒」という期限に実質的な意味がない
  //   - 条件が噛み合うと、正当に開いたウィンドウが自分を閉じてしまい、
  //     利用者からは「アイコンを押したのに何も起きない」ように見える
  //
  // ウィンドウの重複は background.js 側で既に防いでいるため、二重管理をやめた。
  // 残っている古い印は掃除しておく。
  try { localStorage.removeItem("filterWindowMaster"); } catch (e) {}

  /////////////////////////////////////////////////////////////
  // 7. ボタンイベント設定と初期ロード
  // フィルタ入力欄の自動更新
  if (document.getElementById("filterInput")) {
    document.getElementById("filterInput").addEventListener("input", updateFilteredSources);
  }
    
  // 表示順プルダウンの自動更新
  if (document.getElementById("sortOrder")) {
    document.getElementById("sortOrder").addEventListener("change", updateFilteredSources);
  }

  // Clear ボタンの設定
  if (document.getElementById("clearFilter")) {
    document.getElementById("clearFilter").addEventListener("click", function() {
      let input = document.getElementById("filterInput");
      if (input) {
        input.value = "";
        updateFilteredSources();
      }
    });
  }
  
  // Delete Selected Sources ボタンの設定（対象はフィルタ済みのソース）
  if (document.getElementById("deleteSelected")) {
    document.getElementById("deleteSelected").addEventListener("click", function () {
      let selectedIds = filteredSources.filter(s => s.selected).map(s => s.id);
      console.log("削除対象のID:", selectedIds);
      if (selectedIds.length === 0) {
        alert(i18nMessage("noDeleteTargetAlert") || "削除対象が選択されていません");
        return;
      }
      if (!confirm(i18nMessage("deleteConfirmMessage") + selectedIds.length)) {
        return;
      }
      
      // 削除進捗表示用コンテナの生成
      let reloadBtn = document.getElementById("reloadSources");
      let delContainer = document.getElementById("deletionContainer");
      if (!delContainer) {
        delContainer = document.createElement("div");
        delContainer.id = "deletionContainer";
        if (reloadBtn) {
          reloadBtn.insertAdjacentElement("afterend", delContainer);
        } else {
          this.insertAdjacentElement("afterend", delContainer);
        }
      }
      
      // 進捗バーの生成
      let delProg = document.getElementById("deletionProgressBar");
      if (!delProg) {
        delProg = document.createElement("progress");
        delProg.id = "deletionProgressBar";
        delProg.max = selectedIds.length;
        delContainer.appendChild(delProg);
      }
      
      // 進捗ステータスの生成
      let delStatus = document.getElementById("deletionStatus");
      if (!delStatus) {
        delStatus = document.createElement("div");
        delStatus.id = "deletionStatus";
        delContainer.appendChild(delStatus);
      }

      // 中断ボタン。削除は取り消せないため、走り出したあとに止める手段を用意する。
      let abortBtn = document.getElementById("abortDeletion");
      if (!abortBtn) {
        abortBtn = document.createElement("button");
        abortBtn.id = "abortDeletion";
        abortBtn.style.marginTop = "8px";
        delContainer.appendChild(abortBtn);
      }
      abortBtn.disabled = false;
      abortBtn.innerText = i18nMessage("abortDeletionButton");
      abortBtn.onclick = function () {
        abortBtn.disabled = true;
        abortBtn.innerText = i18nMessage("abortDeletionRequested");
        chrome.runtime.sendMessage({ action: "abortDelete" }, () => {
          if (chrome.runtime.lastError) { /* 応答が無くても中断要求は届いている */ }
        });
      };
      delStatus.innerText = i18nMessage("deletionInProgress") || "削除中...";

      // 前回の削除状態が残っていると進捗の合計件数が更新されず、
      // 完了判定に到達しないまま「削除中...」で固まる。開始時に必ず初期化する。
      deletionState = { total: selectedIds.length, processed: 0, errorCount: 0 };
      delProg.max = selectedIds.length;
      delProg.value = 0;

      chrome.runtime.sendMessage({ action: "deleteSelected", ids: selectedIds }, function(response) {
        console.log("deleteSelected 応答:", response);
        // 応答を捨てていたため、ページと通信できない場合でも
        // 「削除中...」の表示のまま何も起きないように見えていた。
        const failed = chrome.runtime.lastError || (response && response.error);
        if (failed) {
          delContainer.remove();
          deletionState = { total: 0, processed: 0, errorCount: 0 };
          showLoadFailureBanner((response && response.errorCode) || "SCRIPT_UNAVAILABLE");
        }
      });
    });
  }

let deletionState = {
  total: 0,
  processed: 0,
  errorCount: 0
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "deletionProgress") {
    const delProg = document.getElementById("deletionProgressBar");
    const delStatus = document.getElementById("deletionStatus");
    const delContainer = document.getElementById("deletionContainer");

    // 初期化済みか確認
    if (!delProg || !delStatus || !delContainer) return;

    // 中断された場合はここで打ち切る
    if (message.status === "aborted") {
      delStatus.innerText = i18nMessage("deletionAborted")
        + `（${deletionState.processed}/${deletionState.total}）`;
      const ab = document.getElementById("abortDeletion");
      if (ab) ab.remove();
      setTimeout(() => {
        reloadSources();
        delContainer.remove();
        deletionState = { total: 0, processed: 0, errorCount: 0 };
      }, 1800);
      return;
    }

    // 初回に合計件数を保存
    if (deletionState.total === 0 && message.total) {
      deletionState.total = message.total;
    }

    // 処理済み件数・エラー件数を更新
    deletionState.processed = message.processed;
    if (message.status === "error") {
      deletionState.errorCount = message.errorCount || (deletionState.errorCount + 1);
    }

    // プログレスバー更新
    delProg.max = deletionState.total;
    delProg.value = deletionState.processed;

    // ステータス更新
    delStatus.innerText = `進捗: ${deletionState.processed}/${deletionState.total} 件, エラー: ${deletionState.errorCount}`;

    // 完了処理
    if (deletionState.processed === deletionState.total) {
      delStatus.innerText = i18nMessage("deleteFinishedMessage") || "削除完了";
      setTimeout(() => {
        reloadSources();
        delContainer.remove();
        // 状態初期化
        deletionState = { total: 0, processed: 0, errorCount: 0 };
      }, 1000);
    }
  }
});
    
  // Reload ボタンの追加（Delete Selected の隣に配置）
  if (document.getElementById("deleteSelected") && !document.getElementById("reloadSources")) {
    let reloadBtn = document.createElement("button");
    reloadBtn.id = "reloadSources";
    reloadBtn.innerText = i18nMessage("reloadButton") || "再読み込み";
    reloadBtn.addEventListener("click", reloadSources);
    document.getElementById("deleteSelected").insertAdjacentElement("afterend", reloadBtn);
  }

  // 使い方の枠の開閉状態を復元
  setupHelpBoxes();

  // 初期ソース取得
  reloadSources();
});
